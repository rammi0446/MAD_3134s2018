<?php
  session_start();

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // delete the variable from the SESSION
    unset($_SESSION["userLoggedIn"]);
  }

  /*
  if (isset($_SESSION["userLoggedIn"]) == true) {
    // if person is logged in, show them this page!
    if ($_SESSION["userLoggedIn"] == true) {
      echo "User is logged in!";
    }
  }
  else {
    echo "Error, person is not logged in";
    //header("Location: page1.php");
  }
  */
?>

<!DOCTYPE html>
<html>
<head>
  <title> Page 2 </title>
  <style type="text/css">
    h1 {
      background-color: yellow;
    }
  </style>
</head>
<body>

<?php
  if (isset($_SESSION["userLoggedIn"]) == true && $_SESSION["userLoggedIn"] == true) {
?>
  <h1> Here is page 2 </h1>.

  <form action="home.php" method="POST">
    <button type="submit">Logout</button>
  </form>

<?php
} else {
  header("Location: signin.php");

}
?>


</body>
</html>