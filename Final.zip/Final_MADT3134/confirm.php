<?php
echo "<h2 style='text-align:center;width:70%;'> Thank you for your order. Please check your email for a confirmation. </h2>";
echo "<br>";
echo "<a href='home.php'>Go To home Page</a>";
?>
