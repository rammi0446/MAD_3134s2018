<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Sign In</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  </head>
  <body>
<div style="width:500px; margin:0 auto; margin-top: 10%; padding:20px; border:2px solid grey;">
	<form>
<div class="field">
<div class="control">
  <button class="button button is-danger is-fullwidth"><a href="showAdmin.php">Users/Admin</a></button>
</div></div>
<div class="field">
<div class="control">
  <button class="button button is-danger is-fullwidth"><a href="showImages.php">Images</a></button>
</div>
</div>

</form>
</div>
</body>
</html>