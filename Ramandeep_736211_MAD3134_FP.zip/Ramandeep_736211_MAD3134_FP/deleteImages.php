<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  $id = $_GET["pos"];
  $dbhost = "localhost";    // address of your database
      $dbuser = "root";         // database username
      $dbpassword = "";         // database password: on MAMP, this is "root"
      $dbname = "airbnb";              // @TODO: database name
      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // 3. Query database for a location that matches the id
      echo $id;
      $sql = "DELETE from images WHERE imageid = $id";

      $results = mysqli_query($conn, $sql);
     // $x = mysqli_fetch_assoc($results);    //you don't need a while loop because you only get 1 thing back
    // $results = mysqli_query($conn, $query);

    $sql = "DELETE from cities WHERE Id = $id";
     $results = mysqli_query($conn, $sql);

     // 4. If successful, redirect user to previous page
        if ($results) {
          header("Location: showImages.php");
        }
        // 5. If failure, show an error message
        else {
          echo "An error occured while deleting your data.";
        }
  }
  ?>
