<?php
session_start();
 $user = $_SESSION["id"];
 print_r($_SESSION);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
//   if ($_SESSION["username"]) {
//     echo "hi";
//   } else {
//     echo "bi";
//   }



      // $dbhost = "localhost";
      // $dbuser = "root";
      // $dbpassword = "";
      // $dbname = "airbnb";

      // $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // // SQL QUERY: 'SELECT * FROM users where username="pritesh" and password="1234"';
      // // ---------------------user------------------------
      // $queryUser = "SELECT * from user WHERE id=" .$userID ;
      // $resultsUser = mysqli_query($conn, $queryUser);
      // $x = mysqli_fetch_assoc($resultsUser);
      // $yUser = mysqli_num_rows($resultsUser);
       //you don't need a while loop because you only get 1 thing back




      // credit card luhn's algo
  $cc = $_POST["ccNumber"];

  for ($i = 0; $i <16; $i=$i+2) {
    $x = $cc[$i]*2;
    if ($x > 9) {
      $x = $x - 9;
    }
    $cc[$i] = $x;
  }
  $total = 0;
  for ($j = 0; $j < 16; $j++) {
    $total = $total + $cc[$j];
  }
  if ($total % 10 == 0) {
    echo "<h2> Thank you for your order. Please check your email for a confirmation. </h2>";

    // if credit card no is valid, then we'll send SMS

    // code to send SMS via TWILIO

    include './vendor/autoload.php';
         // get mobile no from database

    $sid = "AC86bfe15f72763b4f85c15e4554f33636";
    $token = "01f42012a1fc59ec9fa4b6f5cb719106";

    $client = new Twilio\Rest\Client($sid,$token);
    $client->messages->create(
        // the number you'd like to send the message to
        '+14372888588',
        array(
            // A Twilio phone number you purchased at twilio.com/console
            'from' => '+19029154223',
            // the body of the text message you'd like to send
            'body' => 'Your room is booked successfully'
        )
    );

    // header("Location: page2.php");


    // code to send Email/

    $message = "hiii";
    $headers = "From: sagarsaini3993@gmail.com";
    mail("sagarsaini3993@gmail.com","Thank you for your order. Please check your email for a confirmation.",$message,$headers);


  }
  else {
    echo "<h2> Your credit card is invalid, please try again.</h2>";
  }




  }


 ?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Credit Card</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.css" rel="stylesheet"/>
  </head>
  <body>

<form method="post" action="creditcard.php">
<div style="height:500px; width:500px; border:1px solid red; margin:auto;">
<label class="label">Welcome <?php echo $user;?></label>

<div class="field">
  <label class="label">First Name</label>
  <div class="control">
    <input class="input" type="text" placeholder="Text input" required>
  </div>
</div>

<div class="field">
  <label class="label">Last name</label>
  <div class="control">
    <input class="input" type="text" placeholder="Text input" required>
  </div>
</div>

<div class="field">
  <label class="label">Credit Card No.</label>
  <div class="control">
    <input class="input" type="text" placeholder="Text input" name="ccNumber" required>
  </div>
</div>

<div class="field is-grouped">
  <div class="control">
    <button class="button is-link">Submit</button>
  </div>

</div>
</div>
</form>


  </body>
</html>
