
<!DOCTYPE html>
<html>
<head>
  <title> Page 2 </title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
  <link href="css/style.css" rel="stylesheet" type="text/css" />
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

</head>
<body>
<!------------------- main div ---------------------->
<div style="height:2000px">


<!-----------------------image----------------------->
<div class="bg" style="height:700px; border:1px solid green;">

  <div class="tabs is-right">
    <ul>
      <li class="is-active"><a>Become a host</a></li>
      <li><a>Help</a></li>
      <li><a href="signup.php">Signup</a></li>
      <li><a href="signin.php">Login</a></li>
    </ul>
  </div>
</div>
<!------------------------- content ---------------------->
<div style="height:1300px border:1px solid red">


  <div class="columns">
    <div class="column" style="padding:20px; margin:5px; font-family: 'Open Sans', sans-serif;">
      Explore AirBnb
    </div>

  </div>

  <div class="columns" style="padding:60px;">
      <!-- left -->
  <div class="column" style="border:0.5px solid grey; box-shadow: 0 0 5px 0px black">
    <div style="height:100%; width:40%; padding:0 px; float: left;">
      <img src="images/home.jpeg">
    </div>

    <div>
      <h3  style="text-align: center;">Homes</h3>
    </div>
  </div>


    <!--center -->

    <div class="column" style="border:0.5px solid grey; box-shadow: 0 0 5px 0px black">
      <div style="height:100%; width:40%; padding:0px; float: left;">
        <img src="images/home.jpeg">
      </div>

      <div>
        <h3  style="text-align: center;">Experiences</h3>
      </div>
</div>



    <div class="column" style="border:0.5px solid grey; box-shadow: 0 0 5px 0px black">
      <div style="height:100%; width:40%; padding:0px; float: left;">
        <img src="images/home.jpeg">
      </div>

      <div>
        <h3 style="text-align: center;">Restaurants</h3>
      </div>
</div>

</div>


  <div style="padding-left:60px;">
    <p><strong>Introducing AirBnb Plus</strong></p>
  </div>

  <br>
<div style="padding-left:60px;">
  <h2 style="padding:10px;">A new selection of homes verified for quality and comfort</h2>
</div>

  <div style="padding-left:60px; width:1500px;">
    <img src="images/1.jpg">
  </div>

  <div style="padding-top:40px; padding-left:60px;"><strong>Homes around the world</strong></div>

  <!-- for loop images div -->


<!-- <div id="wrapper" style="float:left; width: 25%; padding: 5px; border: 2px solid red; height:100px;">

</div> -->









   <div class="row" style="height: 500px; border:2px solid red; padding:40px;">
 <div class="column" style="width:25%; padding-left:60px;">
     <img src=" images/1.jpg" alt="1" style="width:260px; height:200px;" padding:"5px">
      <img src=" images/1.jpg" alt="1" style="width:260px; height:200px;" padding:"5px">
</div>
      <div class="column" style="width:25%">
        <img src=" images/2.jpg" alt="2" style="width:260px; height:200px;" padding:"5px">
        <img src=" images/2.jpg" alt="2" style="width:260px; height:200px;" padding:"5px">
     </div>

     <div class="column" style="width:25%">
       <img src=" images/1.jpg" alt="3" style="width:260px; height:200px;" padding:"5px">
         <img src=" images/1.jpg" alt="3" style="width:260px; height:200px;" padding:"5px">

     </div>

     <div class="column" style="width:25%;">
       <img src=" images/2.jpg" alt="4" style="width:260px; height:200px;" padding:"5px">
         <img src=" images/2.jpg" alt="4" style="width:260px; height:200px;" padding:"5px">

     </div>


    </div>









<!-- <div>
  <figure class="image is-128x128" style="float:left; margin:20px;">
    <img src="images/2.jpg">
  </figure>

  <figure class="image is-600x480" style="float:left;">
  <img src="https://bulma.io/images/placeholders/128x128.png">
</figure>

<figure class="image is-600x480" style="float:left;">
  <img src="https://bulma.io/images/placeholders/128x128.png">
</figure>

</div> -->

<!-- <div class="row">
  <div class="column">
    <img src="1.jpg" alt="Snow" style="width:100%">
  </div>
  <div class="column">
    <img src="1.jpg" alt="Forest" style="width:100%">
  </div>
  <div class="column">
    <img src="1.jpg" alt="Mountains" style="width:100%">
  </div>
</div> -->















<script src="js/jscript.js"></script>


</body>
</html>
