function multipleImages(){
  var container = document.getElementById("wrapper");
var urls = ["images/1.jpg", "images/1.jpg", "images/1.jpg", "images/1.jpg", "images/1.jpg"];
for( i=0; i<urls.length; i++){
  container.insertAdjacentHTML('beforeend', '<img src="'+urls[i]+'">');
}
}

// multipleImages();
