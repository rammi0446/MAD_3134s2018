<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      // 1. UI: GET the information from the form
      $u = $_POST["email"];
      $p = $_POST["password"];

      // 2. DB: connect to database

      // ----------------------------------------

      $dbhost = "localhost";
      $dbuser = "root";
      $dbpassword = "";
      $dbname = "airbnb";

      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // SQL QUERY: 'SELECT * FROM users where username="pritesh" and password="1234"';
// ----------------admin ----------------------------
      $queryAdmin = "SELECT * from user WHERE username = '$u' and password = '$p' and  checked = 'true' ";
      $resultsAdmin = mysqli_query($conn, $queryAdmin);
      $yAdmin = mysqli_num_rows($resultsAdmin);
      // ---------------------user------------------------
      $queryUser = "SELECT * from user WHERE username = '$u' and password = '$p' and  checked = '' ";
      $resultsUser = mysqli_query($conn, $queryUser);
      $yUser = mysqli_num_rows($resultsUser);

  }
?>








<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Sign In</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  </head>
<body>
<!-- main div -->
<div style="width:500px; margin:0 auto; margin-top: 10%; padding:20px; border:2px solid grey;">
  <!------------------------- Form start ----------------->
<form action="signin.php" method="POST">
  <p>please enter your email address and password to login</p>

<!-- -------------------------email address---------------------------- -->
<div class="field">
  <div class="control  has-icons-right">
    <input class="input" type="text" placeholder="Email Address" name="email">
    <span class="icon is-small is-right">
      <i class="fas fa-envelope"></i>
    </span>
  </div>
</div>

<!-- -----------------------password---------------------------------- -->
  <div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="Enter Password" name="password">
  <span class="icon is-small is-right">
    <i class="fas fa-passport"></i>
    </span>
  </div>
</div>


<!--  -------------------     button------------------------------------->
<?php
 if(isset($yAdmin)) {
  if ($yAdmin == 0 )
  {
   echo "<span style='color:red'> Error - wrong username/password </span><br>";
  }
  else {
              // 5. set a session variable to show the person is logged in
      session_start();
      $_SESSION["userLoggedIn"] = true;
      header("Location: admin.php");
  }
 }
 if(isset($yUser)) {
  if ($yUser == 0 )
  {
   echo "<span style='color:red'> Error - wrong username/password </span><br>";
  }
  else {
              // 5. set a session variable to show the person is logged in
      session_start();
      $_SESSION["userLoggedIn"] = true;
      header("Location: home.php");
  }
 }
 ?>
<div class="field">
<div class="control">
  <button class="button button is-danger is-fullwidth" type="submit">Sign In</button>
</div>
</div>
<p>Don't have account? <a href="signup.php"> Sign Up </a></p>
<!-- ---------------------------end form------------------------------ -->
</form>
<!-- -----------------------------end of main div--------------------- -->
</div>
</body>
</html>
