


<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      // 1. UI: GET the information from the form
      $u = $_POST["username"];
      $first = $_POST["firstName"];
      $last = $_POST["lastName"];
      $pass = $_POST["password"];
      //connnect to database

      $dbhost = "localhost";
      $dbuser = "root";
      $dbpassword = "";
      $dbname = "airbnb";

      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // SQL QUERY: 'SELECT * FROM users where username="pritesh" and password="1234"';

// $query = "SELECT * from login WHERE username = '$u' and password = '$p'";
$query = "INSERT into user (username,first_name,last_name,password) VALUES('$u','$first','$last','$pass')";

      $results = mysqli_query($conn, $query);


      // 4. If successful, redirect user to previous page
         if ($results) {
           header("Location: signin.php");
         }
         // 5. If failure, show an error message
         else {
           echo "An error occured while saving your data.";
         }



      // ----------------------------------------
  }
?>






<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Sign up</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  </head>
<body>
<!-- main div -->


<div style="width:500px; margin:0 auto; margin-top: 10%; padding:20px; border:2px solid grey;">

<form action="signup.php" method="POST">

<!-- -------------------------email address---------------------------- -->
<div class="field">
  <div class="control  has-icons-right">
    <input class="input" type="text" placeholder="Email Address" name="username">
    <span class="icon is-small is-right">
      <i class="fas fa-envelope"></i>
    </span>
  </div>
</div>
<!-- ------------------------------first name --------------------------->
<div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="First Name" name="firstName">
    <span class="icon is-small is-right">
      <i class="fas fa-user"></i>
    </span>
  </div>
</div>
<!-- ------------------------last name--------------------------------- -->
  <div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="Last Name" name="lastName">
    <span class="icon is-small is-right">
      <i class="fas fa-user"></i>
    </span>
  </div>
</div>
<!-- -----------------------password---------------------------------- -->
  <div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="Create a Password" name="password">
  <span class="icon is-small is-right">
    <i class="fas fa-passport"></i>
    </span>
  </div>
</div>

<!-- ----------------------Birthday ------------------------------------->
 <label class="label">Birthday</label>
<p style="color:grey;">To Sign up,You must be 18 or older. Other people would not see your birthday.</p>
<div class="control">
  <div class="select" >
    <select>
      <option>Month</option>
      <option>January</option>
      <option>Febrarury</option>
      <option>March</option>
      <option>April</option>
      <option>May</option>
      <option>June</option>
      <option>July</option>
      <option>August</option>
      <option>September</option>
      <option>October</option>
      <option>November</option>
      <option>December</option>
    </select>
  </div>
  <div class="select" >
    <select >
    <option>Day</option>
      <option>1</option>
      <option>2</option>
      <option>3</option>
      <option>4</option>
      <option>4</option>
      <option>5</option>
      <option>6</option>
      <option>7</option>
      <option>8</option>
      <option>9</option>
      <option>10</option>
      <option>11</option>
      <option>12</option>
      <option>13</option>
      <option>14</option>
      <option>15</option>
      <option>16</option>
      <option>17</option>
      <option>18</option>
      <option>19</option>
      <option>20</option>
      <option>21</option>
      <option>22</option>
      <option>23</option>
      <option>24</option>
      <option>25</option>
      <option>26</option>
      <option>27</option>
      <option>28</option>
      <option>29</option>
      <option>30</option>
      <option>31</option>
    </select>
  </div>
  <div class="select">
    <select>
      <option>Year</option>
      <option></option>
    </select>
  </div>
</div>

<p style="color:grey;">We'll send you marketing promotions, special offers, inspirations and policy updates via email</p>
<!--  -------------------     button------------------------------------->
<div class="field">
<div class="control">
  <button type="submit" class="button button is-danger is-fullwidth">Sign Up</button>
</div>
</div>

<p style="color:grey;">i don't want to recieve marketing messages from AirB&B. I can also opt out of receveing these at any time in my account setting or via the link in the message </p>
<!-- -----------------------------end of main div--------------------- -->
</form>
</div>

</body>
</html>
