<?php
include("header.php");
//  if ($_SERVER["REQUEST_METHOD"] == "GET"){
      // 1. Get location id from the URL
      $cardID = $_GET["pos"];

      // 2. DB: Connect to database
      $dbhost = "localhost";		// address of your database
      $dbuser = "root";					// database username
      $dbpassword = "";					// database password: on MAMP, this is "root"
      $dbname = "airbnb";							// @TODO: database name
      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // 3. Query database for a location that matches the id
      $sql = "SELECT * FROM images WHERE imageid=" . $cardID;
      $sqlDetail = "SELECT * FROM cities WHERE Id=" .$cardID;
      $results = mysqli_query($conn, $sql);
      $resultsDetail = mysqli_query($conn, $sqlDetail);
      $x = mysqli_fetch_assoc($results);    //you don't need a while loop because you only get 1 thing back
      $xDetail = mysqli_fetch_assoc($resultsDetail);
      //print_r($x);
?>

<!DOCTYPE html>
<html>
<head>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin|Libre+Baskerville|Source+Sans+Pro" rel="stylesheet">
     <script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>
     <style type="text/css">
     /* #pic{
       width: 100%;
       height: 60%;
       position: absolute;
     } */
     .notification {
       height: 8%;
     }
     #star{
     	color: orange;
     }
     #star:hover{
     	color:grey;
     }


.card:hover{
opacity: 0.8;
box-shadow: 0.5px 2px 2px 0px;
}

     </style>
  </head>
</head>

<body>
<div class="section">
   <!-- <div class="container" style="margin-top:20%;width:10%; margin: 0 auto;"> -->

      

          
<!------------------------------ room images ----------------->
        <div class="column" style="margin-top:20%;width:10%; ">
         <div class="card ">
          <div class="card-image">
            <figure class="image is-4by3">
              <img src="<?php echo $x["pic1"]?>" alt="Placeholder image">
            </figure>
          </div>
           </div>
      </div>
        

         <div class="column" style="margin-top:20%;width:10%; ">
         <div class="card ">
          <div class="card-image">
            <figure class="image is-4by3">
              <img src="<?php echo $x["pic2"]?>" alt="Placeholder image">
            </figure>
          </div>
           </div>
      </div>
        

         <div class="column" style="margin-top:20%;width:10%;">
         <div class="card ">
          <div class="card-image">
            <figure class="image is-4by3">
              <img src="<?php echo $x["pic3"]?>" alt="Placeholder image">
            </figure>
          </div>
         </div>
      </div>


        <div class="column" style="margin-top:20%;width:10%;">
         <div class="card ">
          <div class="card-image">
            <figure class="image is-4by3">
              <img src="<?php echo $x["pic4"]?>" alt="Placeholder image">
            </figure>
          </div>
         </div>
      </div>


        <div class="column" style="margin-top:20%;width:10%;">
         <div class="card ">
          <div class="card-image">
            <figure class="image is-4by3">
              <img src="<?php echo $x["pic5"]?>" alt="Placeholder image">
            </figure>
          </div>
        </div>
      </div>
        </div>
      
<!-- ------------------------content--------------------- -->
<?php 
echo $xDetail["name"];
echo "<br>";
echo $xDetail["type"];
echo "<br>";
echo $xDetail["location"];
echo "<br>";
echo $xDetail["price"];
echo "<br>";
echo $xDetail["rating"];
echo "<br>";
echo $xDetail["reviews"];
echo "<br>";
echo $xDetail["superhost"];
echo "<br>";

echo $xDetail["owner"];
echo "<br>";
echo $xDetail["guests"];
echo "<br>";
echo $xDetail["bedrooms"];
echo "<br>";
echo $xDetail["beds"];
echo "<br>";
echo $xDetail["bath"];
echo "<br>";
echo $xDetail["description"];
echo "<br>";
echo $xDetail["free_parking"];
echo "<br>";
echo $xDetail["laptop_friendly_environment"];
echo "<br>";
echo $xDetail["laundry"];
echo "<br>";
echo $xDetail["wifi"];
echo "<br>";
echo $xDetail["kitchen"];
echo "<br>";
echo $xDetail["cable_tv"];
echo "<br>";
echo $xDetail["room"];
echo "<br>";
?>
    
<!-- <script src="script.js"></script> -->
</body>
</body>
</html>
