<?php
  include("header.php");
?>

  <!-- Title -->
   <section class="section">
     <div class="container">
       <h1 class="title has-text-centered">About Us</h1>
       <h2 class="subtitle has-text-centered">
         We make really tasy donuts!
       </h2>
       <div class="content">
         <p>
           Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam scelerisque nisl ac faucibus placerat. Morbi hendrerit vulputate diam sed pretium. Pellentesque nec felis non elit convallis dapibus ut et purus. Nulla facilisi. Donec faucibus pretium elit, vel hendrerit purus accumsan ultricies. Curabitur vitae magna eu ipsum semper feugiat. Curabitur tempus nec eros sed sagittis. Donec sagittis mauris vel lacus blandit, ut feugiat massa rutrum. Curabitur commodo laoreet lacus, in dictum massa scelerisque eget. Curabitur porta ligula sit amet tristique eleifend.
        </p>

        <p>
          Nullam blandit id mauris a imperdiet. Integer quis nunc magna. Pellentesque efficitur eros velit, et euismod metus varius at. Quisque mollis eget mi id lacinia. Phasellus finibus sodales ex, sit amet sodales neque. Nulla aliquet lacus sit amet ex mollis suscipit. Morbi vitae nulla id ex blandit accumsan. Cras vitae erat nec libero mattis vestibulum vitae nec ex. Ut augue turpis, interdum et orci a, iaculis tincidunt massa. Aenean vel felis cursus ex dapibus pharetra. Phasellus sodales dictum euismod. Proin at consequat magna. Curabitur a mi ac arcu blandit molestie at sed odio. Proin egestas hendrerit neque ut faucibus. In sapien nisl, porta sed varius placerat, pretium vel diam. Sed posuere ligula vitae ligula fermentum tempus.
        </p>

        <p>
          Pellentesque augue justo, mattis nec turpis non, rutrum feugiat augue. Quisque sem velit, elementum at dui vitae, interdum pretium orci. Fusce sit amet mi vitae justo dignissim viverra. Cras nec nisl augue. Proin auctor, turpis quis eleifend scelerisque, metus lacus lobortis odio, finibus volutpat leo diam vel sapien. Cras finibus vehicula nisi, quis luctus sem convallis in. Donec arcu libero, efficitur vitae lacus nec, lacinia sodales lorem. Vestibulum tristique erat et turpis maximus aliquet. Nulla ut blandit mi. Morbi at eros bibendum ex luctus porta eget non elit. Vivamus eget dui non nisl sagittis ultricies ut a felis.
        </p>

      </div><!-- // div class=content -->
    </div> <!-- // div class="container" -->
   </section>

   <script type="text/javascript">
   </script>
 </body>
</html>
