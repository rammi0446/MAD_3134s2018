<?php
  include("header.php");
?>
    <!-- Title -->
   <section class="section">
     <div class="container">
       <h1 class="title has-text-centered">Locations</h1>
       <h2 class="subtitle has-text-centered">
         Check out all our cool stores near you!
       </h2>

       <div class="content">
         <!-- connect to the database and get all the locations -->
         <?php
            $dbhost = "localhost";		// address of your database
            $dbuser = "root";					// database username
            $dbpassword = "";					// database password: on MAMP, this is "root"
            $dbname = "store";							// database name

            // 2.  CONNECT TO THE DATABASE
            $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

            // 3.  MAKE a SQL QUERY

            // @TODO: put your sql query here
            $query = "SELECT * from locations";

            // 4. SEND QUERY TO DB & GET RESULTS
            $results = mysqli_query($conn, $query);

            // 5. SHOW THE DATABASE RESULTS SOMEWHERE
            // loop through the database results
            while( $x = mysqli_fetch_assoc($results) ) {
            	// show all row data
              echo "<p class='has-text-centered'>";
                echo "<span class='location'>";
                  echo $x["name"] . "<br>";
                echo "</span>";
                echo $x["address"];
                echo "<br>";
                echo $x["city"] . ", " . $x["province"];
                echo "<br>";
                echo $x["phone"];
              echo "</p>";

            }
            ?>
        </div> <!-- class=content -->
     </div>
   </section>

   <script type="text/javascript">
   </script>
 </body>
</html>
