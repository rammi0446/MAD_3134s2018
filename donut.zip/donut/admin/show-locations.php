<?php

  // 1. connect to DATABASE
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "store";							// database name

  // 2.  CONNECT TO THE DATABASE
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

  // 3.  MAKE a SQL QUERY

  $query = "SELECT * from locations";

  // 4. SEND QUERY TO DB & GET RESULTS
  $results = mysqli_query($conn, $query);

  // 5. SHOW THE DATABASE RESULTS SOMEWHERE
  // loop through the database results




?>

<!DOCTYPE html>
<html>
<head>
  <!-- bulma -->
  <link href="css/bulma.min.css" rel="stylesheet" type="text/css">
</head>
<body>
  <div class="content">
    <h1> Locations </h1>

    <!-- @TODO: make a table & put all the location data in it-->
    <!--------------------------------------------------->

<?php
    while( $x = mysqli_fetch_assoc($results) ) {
      // show all row data
      //print_r($x);

      echo $x["name"];
      echo $x["city"];
      echo $x["phone"];
      echo '<a href="edit-location.php?pos='.$x["id"].'"> |Edit| </a>';
      echo '<a href="delete-location.php">    |Delete| </a>';
      echo "<br>";
}
?>


    <!--------------------------------------------------->
    <a href="add-location.php" class="button"> + Add Location </a> <br><br>
    <a href="index.php" class="button"> < Go Home </a>
  </div>
</body>
</html>
