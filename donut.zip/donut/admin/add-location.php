<?php

  // 1. Get the data from the form
if($_SERVER["REQUEST_METHOD"] == "POST"){
print_r($_POST);
$name = $_POST["name"];
$city = $_POST["city"];
$address = $_POST["address"];
$prov = $_POST["province"];
$phone = $_POST["phone"];

  // 2. Connect to the database
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "store";							// database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

  // 3. Insert data into the db

  $query = "insert into locations(name,city,address,province,phone)values"
  .'("'
  .$name
  .'","'
  .$city
  .'","'
  .$address
  .'","'
  .$prov
  .'","'
  .$phone
  .'")'
  ;
  echo $query;
  $results = mysqli_query($conn, $query);

  // 4. If successful, redirect user to previous page


  // 5. If failure, show an error message
}
?>

<!DOCTYPE html>
<html>
<head>
  <!-- bulma -->
  <link href="css/bulma.min.css" rel="stylesheet" type="text/css">
</head>
<body>
  <div class="content">
    <h1> Add Location </h1>

    <!-- @TODO:  Create a form that lets user add to database-->
    <!--------------------------------------------------->
    <div style="width:30%; margin:0 auto;">
<form action="add-location.php" method="post">
  <div class="field">
  <div class="control">
    <input class="input" type="text" name="name" placeholder="Name">
  </div>
</div>

<div class="field">
<div class="control">
  <input class="input" type="text" name="address" placeholder="Address">
</div>
</div>

<div class="field">
<div class="control">
  <input class="input" type="text" name="city" placeholder="City">
</div>
</div>

<div class="field">
<div class="control">
  <input class="input" type="text" name="province" placeholder="province">
</div>
</div>
<div class="field">
<div class="control">
  <input class="input" type="text" name="phone" placeholder="phone">
</div>
</div>

<div class="field">
<div class="control">
  <button type="submit">Add Location</button>
</div>
</div>

</form>
</div>



    <!--------------------------------------------------->
    <a href="show-locations.php" class="button"> < Go Back </a>
  </div>
</body>
</html>
