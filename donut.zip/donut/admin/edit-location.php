<?php

  // 1. Check how the person arrived at the page.
  // --> If GET, then get the location id from the URL & show the location data
  // --> If POST, then save the changes to the database



  // GET REQUEST:  This means the user got here by clicking on the "Edit" button
  // on previous page
  // ---------------------------------
  if ($_SERVER["REQUEST_METHOD"] == "GET"){
      // 1. Get location id from the URL
$locationId = $_GET["pos"];
      // 2. DB: Connect to database
      $dbhost = "localhost";		// address of your database
      $dbuser = "root";					// database username
      $dbpassword = "";					// database password: on MAMP, this is "root"
      $dbname = "store";							// database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // 3. Query database for a location that matches the id
$query = "SELECT * from locations where id=".$locationId;
echo $query;
$results = mysqli_query($conn, $query);
while( $x = mysqli_fetch_assoc($results) ) {
  // show all row data
  echo "<p class='has-text-centered'>";
    echo "<span class='location'>";
      echo $x["name"] . "<br>";
    echo "</span>";
    echo $x["address"];
    echo "<br>";
    echo $x["city"] . ", " . $x["province"];
    echo "<br>";
    echo $x["phone"];
  echo "</p>";

}
      // 4. If you find a match, then put row data into the form

      // 5. If no match, then redirect back to previous page


  }
  // POST REQUEST: This means the user got here by pressing "Save Changes" button
  // in the form below
  else if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Get data from the form
    print_r($_POST);
    $name = $_POST["name"];
    $city = $_POST["city"];
    $address = $_POST["address"];
    $prov = $_POST["province"];
    $phone = $_POST["phone"];

      // 2. Connect to the database
      $dbhost = "localhost";		// address of your database
      $dbuser = "root";					// database username
      $dbpassword = "";					// database password: on MAMP, this is "root"
      $dbname = "store";							// database name
      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // 3. Insert data into the db

      $query = "update locations(name,city,address,province,phone)values"
      .'("'
      .$name
      .'","'
      .$city
      .'","'
      .$address
      .'","'
      .$prov
      .'","'
      .$phone
      .'")'
      ;
      echo $query;
      $results = mysqli_query($conn, $query);
    // 2. DB: Connect to the database

    // 3. DB: Update the database with the new info

    // 4. UI: If successful, redirect user back to previous page

    // 5. UI: Otherwise, show an error message
  }



  // 2. Connect to the database


  // 3. Insert data into the db


  // 4. If successful, redirect user to previous page


  // 5. If failure, show an error message

?>

<!DOCTYPE html>
<html>
<head>
  <!-- bulma -->
  <link href="css/bulma.min.css" rel="stylesheet" type="text/css">
</head>
<body>
  <div class="content">
    <h1> Add Location </h1>

    <!-- @TODO:  Create a form that lets user edit a row-->
    <!-- This code should be similar to the add-location page -->
    <!--------------------------------------------------->

    <div style="width:30%; margin:0 auto;">
  <form action="edit-location.php" method="post">
  <div class="field">
  <div class="control">
    <input class="input" type="text" value="<?php echo $x['name']; ?>" name="name" placeholder="Name">
  </div>
  </div>

  <div class="field">
  <div class="control">
  <input class="input" type="text" name="address" placeholder="Address">
  </div>
  </div>

  <div class="field">
  <div class="control">
  <input class="input" type="text" name="city" placeholder="City">
  </div>
  </div>

  <div class="field">
  <div class="control">
  <input class="input" type="text" name="province" placeholder="province">
  </div>
  </div>
  <div class="field">
  <div class="control">
  <input class="input" type="text" name="phone" placeholder="phone">
  </div>
  </div>

  <div class="field">
  <div class="control">
  <button type="submit">edit Location</button>
  </div>
  </div>

  </form>
  </div>






    <!--------------------------------------------------->
    <a href="show-locations.php" class="button"> < Go Back </a>
  </div>
</body>
</html>
